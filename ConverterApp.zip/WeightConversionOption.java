public class WeightConversionOption {
    private double kilograms;

    public double getKilograms() {
        return kilograms;
    }

    public void setKilograms(double kilograms) {
        this.kilograms = kilograms;
    }
}
